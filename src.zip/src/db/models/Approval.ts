import db from "./db";

export class ModelError extends Error { code: string; http: number; constructor(code: string, msg: string, http = 400) { super(msg); this.code = code; this.http = http; } }
const dbGuard = async <T>(fn: () => Promise<T>, msg: string): Promise<T> => { try { return await fn(); } catch (e: any) { if (e instanceof ModelError) throw e; throw new ModelError("DB_ERROR", e?.message || msg, 500); } };
const mapFk = (e: any, fallback = "FK violation") => {
  if (e?.code === "23503") {
    const d = String(e?.detail || "");
    if (d.includes("chore_uuid")) return new ModelError("CHORE_NOT_FOUND", "Chore not found", 404);
    if (d.includes("user_email")) return new ModelError("USER_NOT_FOUND", "User not found", 404);
    return new ModelError("FK_VIOLATION", fallback, 409);
  }
  return new ModelError("DB_ERROR", e?.message || fallback, 500);
};

export default class Approval {
  static async voters(choreUuid: string): Promise<string[]> {
    const rows = await db("chore_approvals").where({ chore_uuid: choreUuid });
    return rows.map((r: any) => r.user_email as string);
  }

  static async vote(choreUuid: string, userEmail: string) {
    return dbGuard(async () => {
      try {
        await db("chore_approvals")
          .insert({ chore_uuid: choreUuid, user_email: userEmail })
          .onConflict(["chore_uuid", "user_email"]).ignore();
        return this.voters(choreUuid);
      } catch (e: any) { throw mapFk(e, "Chore or user does not exist"); }
    }, "Failed to vote");
  }

  static async unvote(choreUuid: string, userEmail: string) {
    return dbGuard(async () => {
      await db("chore_approvals").where({ chore_uuid: choreUuid, user_email: userEmail }).del();
      return this.voters(choreUuid);
    }, "Failed to remove vote");
  }
}