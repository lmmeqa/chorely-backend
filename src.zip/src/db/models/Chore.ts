import db from "./db";

export class ModelError extends Error {
  code: string; http: number;
  constructor(code: string, message: string, http = 400) { super(message); this.code = code; this.http = http; }
}
const dbGuard = async <T>(fn: () => Promise<T>, msg: string): Promise<T> => { try { return await fn(); } catch (e: any) { if (e instanceof ModelError) throw e; throw new ModelError("DB_ERROR", e?.message || msg, 500); } };
const mapFk = (e: any, fallback = "FK violation") => {
  if (e?.code === "23503") {
    const d = String(e?.detail || "");
    if (d.includes("home_id")) return new ModelError("HOME_NOT_FOUND", "Home not found", 404);
    if (d.includes("user_email")) return new ModelError("USER_NOT_FOUND", "User not found", 404);
    return new ModelError("FK_VIOLATION", fallback, 409);
  }
  return new ModelError("DB_ERROR", e?.message || fallback, 500);
};

export type ChoreStatus = "unapproved" | "unclaimed" | "claimed" | "complete";

export interface ChoreRow {
  uuid: string;
  name: string;
  description: string;
  time: string; // timestamptz
  icon: string;
  status: ChoreStatus;
  user_email: string | null;
  home_id: string;
  points: number;
  completed_at: string | null;
  created_at?: string;
  updated_at?: string;
}

export default class Chore {
  static async create(data: Omit<ChoreRow, "uuid" | "status" | "user_email" | "completed_at" | "created_at" | "updated_at"> & { user_email?: string | null }) {
    return dbGuard(async () => {
      try {
        return (await db<ChoreRow>("chores")
          .insert({ ...data, status: "unapproved", user_email: data.user_email ?? null, completed_at: null })
          .returning("*"))[0];
      } catch (e: any) {
        throw mapFk(e, "Failed to create chore");
      }
    }, "Failed to create chore");
  }

  static async findByUuid(uuid: string): Promise<ChoreRow> {
    return dbGuard(async () => {
      const row = await db<ChoreRow>("chores").where({ uuid }).first();
      if (!row) throw new ModelError("CHORE_NOT_FOUND", `Chore not found: '${uuid}'`, 404);
      return row;
    }, "Failed to fetch chore");
  }

  static available(homeId: string) {
    return db<ChoreRow>("chores").where({ home_id: homeId, status: "unclaimed" }).andWhere("user_email", null);
  }
  static unapproved(homeId: string) {
    return db<ChoreRow>("chores").where({ home_id: homeId, status: "unapproved" });
  }
  static forUser(email: string, homeId: string) {
    return db<ChoreRow>("chores").where({ user_email: email, home_id: homeId }).whereIn("status", ["claimed", "complete"]);
  }

  static async setStatus(uuid: string, status: ChoreStatus) {
    return dbGuard(async () => {
      const n = await db("chores").where({ uuid }).update({ status });
      if (!n) throw new ModelError("CHORE_NOT_FOUND", `Chore not found: '${uuid}'`, 404);
    }, "Failed to update chore status");
  }
  
  static async approve(uuid: string){
    await this.setStatus(uuid, "unclaimed")
  }

  static async claim(uuid: string, email: string) {
    return dbGuard(async () => {
      try {
        const n = await db("chores")
          .where({ uuid, status: "unclaimed" })
          .update({ status: "claimed", user_email: email });
        if (!n) throw new ModelError("CHORE_NOT_CLAIMABLE", "Chore is already claimed or not available", 409);
      } catch (e: any) {
        throw mapFk(e, "User does not exist for claim");
      }
    }, "Failed to claim chore");
  }

  static async verify(uuid: string) {
    return dbGuard(async () => {
      const n = await db("chores").where({ uuid }).update({ status: "complete", completed_at: db.fn.now() });
      if (!n) throw new ModelError("CHORE_NOT_FOUND", `Chore not found: '${uuid}'`, 404);
    }, "Failed to complete chore");
  }


}