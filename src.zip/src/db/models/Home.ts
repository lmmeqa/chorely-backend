import db from "./db";

export interface HomeRow {
  id: string;
  name: string;
  created_at?: string;
  updated_at?: string;
}

export default class Home {
  static async create(name: string): Promise<HomeRow> {
    return (await db<HomeRow>("home").insert({ name }).returning("*"))[0];
  }

  static findById(id: string) {
    return db<HomeRow>("home").where({ id }).first();
  }

  static all() {
    return db<HomeRow>("home").orderBy("name");
  }
}