import { Router } from "express";
import Activity from "../db/models/Activity";

const r = Router();

r.get("/", async (_req, res) => {
  res.json(await Activity.recent());
});

export default r;