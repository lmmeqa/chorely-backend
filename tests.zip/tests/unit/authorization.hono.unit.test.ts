import { Hono } from 'hono';
import { describe, it, expect, beforeEach, vi } from 'vitest';

// Mock the database for authorization middleware
type State = {
  user_homes: Array<{ user_email: string; home_id: string }>;
  chores: Map<string, { uuid: string; home_id: string }>;
  disputes: Map<string, { uuid: string; chore_id: string }>;
  throwOnQuery?: boolean;
};

const state: State = {
  user_homes: [],
  chores: new Map(),
  disputes: new Map(),
  throwOnQuery: false,
};

// Mock the database functions
vi.mock('../../src/lib/db', () => ({
  dbFromEnv: () => ({
    select: () => ({
      from: () => ({
        where: () => ({
          limit: () => Promise.resolve(state.throwOnQuery ? 
            Promise.reject(new Error('db fail')) : 
            state.user_homes.length > 0 ? [state.user_homes[0]] : []
          )
        })
      })
    })
  })
}));

// Import after mocks
import {
  requireHomeMemberByParam,
  requireHomeMemberByQuery,
  requireSelfEmailByQuery,
  requireSelfEmailByBody,
  requireSelfEmailByParam,
  requireHomeMemberByChoreUuidParam,
  requireHomeMemberByDisputeUuidParam,
} from '../../src/lib/authorization';

// Helper to create test app with user
function createTestApp() {
  const app = new Hono();
  
  // Middleware to set user context
  app.use('*', async (c, next) => {
    const authHeader = c.req.header('authorization');
    if (authHeader?.startsWith('Bearer user:')) {
      const email = authHeader.split('user:')[1];
      c.set('user', { email });
    }
    await next();
  });
  
  return app;
}

// Helper to make authenticated request
function makeRequest(app: Hono, method: string, path: string, userEmail?: string) {
  const request = new Request(`http://localhost${path}`, {
    method,
    headers: userEmail ? { 'Authorization': `Bearer user:${userEmail}` } : {}
  });
  
  const testEnv = {};
  return app.fetch(request, testEnv);
}

describe('authorization middleware', () => {
  beforeEach(() => {
    state.user_homes = [];
    state.chores.clear();
    state.disputes.clear();
    state.throwOnQuery = false;
  });

  describe('requireHomeMemberByParam', () => {
    it('rejects unauthenticated users when checking home membership via URL parameter', async () => {
      const app = createTestApp();
      app.get('/x/:homeId', requireHomeMemberByParam('homeId'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/x/h1');
      expect(res.status).toBe(401);
    });

    it('rejects requests missing home ID parameter', async () => {
      const app = createTestApp();
      app.get('/x', requireHomeMemberByParam('homeId'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/x', 'a@b.com');
      expect(res.status).toBe(400);
    });

    it('rejects non-members when checking home membership via URL parameter', async () => {
      const app = createTestApp();
      app.get('/x/:homeId', requireHomeMemberByParam('homeId'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/x/h1', 'a@b.com');
      expect(res.status).toBe(403);
    });

    it('allows home members when checking membership via URL parameter', async () => {
      state.user_homes = [{ user_email: 'a@b.com', home_id: 'h1' }];
      
      const app = createTestApp();
      app.get('/x/:homeId', requireHomeMemberByParam('homeId'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/x/h1', 'a@b.com');
      expect(res.status).toBe(200);
    });
  });

  describe('requireHomeMemberByQuery', () => {
    it('rejects unauthenticated users when checking home membership via query parameter', async () => {
      const app = createTestApp();
      app.get('/x', requireHomeMemberByQuery('homeId'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/x?homeId=h1');
      expect(res.status).toBe(401);
    });

    it('rejects requests missing home ID query parameter', async () => {
      const app = createTestApp();
      app.get('/x', requireHomeMemberByQuery('homeId'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/x', 'a@b.com');
      expect(res.status).toBe(400);
    });

    it('allows home members when checking membership via query parameter', async () => {
      state.user_homes = [{ user_email: 'a@b.com', home_id: 'h1' }];
      
      const app = createTestApp();
      app.get('/x', requireHomeMemberByQuery('homeId'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/x?homeId=h1', 'a@b.com');
      expect(res.status).toBe(200);
    });
  });

  describe('requireSelfEmailByParam', () => {
    it('rejects when user email does not match URL parameter', async () => {
      const app = createTestApp();
      app.get('/user/:email', requireSelfEmailByParam('email'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/user/other@user.com', 'a@b.com');
      expect(res.status).toBe(403);
    });

    it('allows when user email matches URL parameter', async () => {
      const app = createTestApp();
      app.get('/user/:email', requireSelfEmailByParam('email'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/user/a@b.com', 'a@b.com');
      expect(res.status).toBe(200);
    });
  });

  describe('database error handling', () => {
    it('handles database failures gracefully', async () => {
      state.throwOnQuery = true;
      
      const app = createTestApp();
      app.get('/x/:homeId', requireHomeMemberByParam('homeId'), (c) => c.json({ ok: true }));
      
      const res = await makeRequest(app, 'GET', '/x/h1', 'a@b.com');
      expect(res.status).toBe(500);
    });
  });
});